/** 
 * Aug 3, 2013
 * Grant Elgin
 * CS 232 HW5
 * 
 * New accounts are required to verify their Chart of Accounts code is not already in use.
 * 
 */

public interface AccountInterface {
	public boolean verifyAccount(Account otherAccount);
}
